package mx.ipn.upiicsa.programacionmovil.citas.entity

import mx.ipn.upiicsa.programacionmovil.citas.entity.Empleado
import java.sql.Date

class DiaDescanso {
    var idDiaDescanso: Int? = null
    var descanso: Date? = null
    var empleado: Empleado? = null

    constructor(idDiaDescanso: Int, descanso: Date, empleado: Empleado) {
        this.idDiaDescanso = idDiaDescanso
        this.descanso = descanso
        this.empleado = empleado
    }
}