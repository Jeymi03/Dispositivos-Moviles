package mx.ipn.upiicsa.programacionmovil.citas.entity

class Usuario {
}