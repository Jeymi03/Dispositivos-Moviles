package mx.ipn.upiicsa.programacionmovil.citas.entity

class Sucursal   {
    var idSucursal: Int? = null
    var nombre: String? = null
    var ubicacion: Int? = null
    var establecimiento: Establecimiento? = null

    constructor(idSucursal: Int, nombre: String, ubicacion: Int, establecimiento: Establecimiento) {
        this.idSucursal = idSucursal
        this.nombre = nombre
        this.ubicacion = ubicacion
        this.establecimiento = establecimiento
    }
}