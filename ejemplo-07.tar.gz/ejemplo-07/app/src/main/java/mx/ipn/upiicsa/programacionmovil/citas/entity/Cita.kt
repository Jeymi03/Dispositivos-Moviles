package mx.ipn.upiicsa.programacionmovil.citas.entity

class Cita(
    val idCita: Int
) {

}