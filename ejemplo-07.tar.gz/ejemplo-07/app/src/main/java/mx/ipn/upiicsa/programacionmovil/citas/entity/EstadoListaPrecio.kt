package mx.ipn.upiicsa.programacionmovil.citas.entity

class EstadoListaPrecio {
    var idEstado: Int? = null
    var nombre: String? = null

    constructor(idEstado: Int, nombre: String) {
        this.idEstado = idEstado
        this.nombre = nombre
    }
}