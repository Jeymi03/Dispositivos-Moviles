package mx.ipn.upiicsa.programacionmovil.citas.entity

import java.sql.Timestamp

class Bloque_Cita {
    var inicio: Timestamp? = null
    var fin: Timestamp? = null

    constructor(inicio: Timestamp, fin: Timestamp) {
        this.inicio = inicio
        this.fin = fin
    }
}