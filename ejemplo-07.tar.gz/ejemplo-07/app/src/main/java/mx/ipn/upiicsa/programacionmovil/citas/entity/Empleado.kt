package mx.ipn.upiicsa.programacionmovil.citas.entity

import mx.ipn.upiicsa.programacionmovil.citas.entity.Sucursal

class Empleado {
    var idEmpleado: Int? = null
    var persona: Persona? = null
    var sucursal: Sucursal? = null

    constructor(idEmpleado: Int, persona: Persona, sucursal: Sucursal) {
        this.idEmpleado = idEmpleado
        this.persona = persona
        this.sucursal = sucursal
    }
}