package mx.ipn.upiicsa.programacionmovil.citas.entity

import java.sql.Timestamp

class ListaPrecio {
    var idListaPrecio: Int? = null
    var nombre: String? = null
    var inicio: Timestamp? = null
    var fin: Timestamp? = null

    constructor(idListaPrecio: Int, nombre: String, inicio: Timestamp, fin: Timestamp) {
        this.idListaPrecio = idListaPrecio
        this.nombre = nombre
        this.inicio = inicio
        this.fin = fin
    }
}