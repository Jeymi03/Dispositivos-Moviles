package mx.ipn.upiicsa.programacionmovil.citas.entity

import java.sql.Time

class Horario{
    var idHorario: Int? = null
    var inicio: Time? = null
    var fin: Time? = null

    constructor(idHorario: Int, inicio: Time, fin: Time) {
        this.idHorario = idHorario
        this.inicio = inicio
        this.fin = fin
    }
}