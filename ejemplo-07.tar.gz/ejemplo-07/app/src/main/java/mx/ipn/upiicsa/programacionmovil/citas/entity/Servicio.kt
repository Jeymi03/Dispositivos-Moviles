package mx.ipn.upiicsa.programacionmovil.citas.entity

class Servicio {
    var idServicio: Int? = null
    var nombre: String? = null
    var descripcion: String? = null
    var activo: Int? = null
    var duracion: Int? = null

    constructor(idServicio: Int, nombre: String, descripcion: String, activo: Int, duracion: Int) {
        this.idServicio = idServicio
        this.nombre = nombre
        this.descripcion = descripcion
        this.activo = activo
        this.duracion = duracion
    }
}