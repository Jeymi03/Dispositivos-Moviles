package mx.ipn.upiicsa.programacionmovil.citas.entity

class ServicioListaPrecio (
    val precio: Int,

)  {
}